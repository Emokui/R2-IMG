import { ThrowableRouter } from 'itty-router-extras';

export const router = ThrowableRouter<Request>({ base: '/rest' });
